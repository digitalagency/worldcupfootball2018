-- phpMyAdmin SQL Dump
-- version 4.3.8
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 07, 2018 at 08:33 AM
-- Server version: 5.5.51-38.2
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `dactechn_worldcup2018`
--

-- --------------------------------------------------------

--
-- Table structure for table `groups`
--

DROP TABLE IF EXISTS `groups`;
CREATE TABLE IF NOT EXISTS `groups` (
  `id` mediumint(8) unsigned NOT NULL,
  `name` varchar(20) NOT NULL,
  `description` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `groups`
--

INSERT INTO `groups` (`id`, `name`, `description`) VALUES
(1, 'admin', 'Administrator'),
(2, 'members', 'General User');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

DROP TABLE IF EXISTS `tbl_admin`;
CREATE TABLE IF NOT EXISTS `tbl_admin` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL DEFAULT '',
  `pass` varchar(50) NOT NULL DEFAULT '',
  `email` varchar(50) NOT NULL DEFAULT '',
  `title` varchar(255) NOT NULL DEFAULT '',
  `status` int(11) DEFAULT NULL,
  `last_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`id`, `username`, `pass`, `email`, `title`, `status`, `last_modified`) VALUES
(1, 'dacadmin', 'a6881ada166f0ba853a2fcce4224ad15', 'customercare@bergernepal.com', 'BERGER PAINTS NEPAL - Rang Magical', NULL, '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_contestants`
--

DROP TABLE IF EXISTS `tbl_contestants`;
CREATE TABLE IF NOT EXISTS `tbl_contestants` (
  `id` int(11) NOT NULL,
  `registration_date` date NOT NULL,
  `full_name` text NOT NULL,
  `mobile` varchar(50) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `facebook_id` varchar(200) NOT NULL,
  `facebook_name` varchar(100) NOT NULL,
  `facebook_email` varchar(100) NOT NULL,
  `facebook_profile_link` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_country`
--

DROP TABLE IF EXISTS `tbl_country`;
CREATE TABLE IF NOT EXISTS `tbl_country` (
  `id` int(11) NOT NULL,
  `country_name` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_country`
--

INSERT INTO `tbl_country` (`id`, `country_name`) VALUES
(1, 'Argentina'),
(2, 'Australia'),
(3, 'Belgium'),
(4, 'Brazil'),
(5, 'Colombia'),
(6, 'Costa Rica'),
(7, 'Croatia'),
(8, 'Denmark'),
(9, 'Egypt'),
(10, 'England'),
(11, 'France'),
(12, 'Germany'),
(13, 'Iceland'),
(14, 'IR Iran'),
(15, 'Japan'),
(27, 'Korea Republic'),
(16, 'Mexico'),
(17, 'Morocco'),
(18, 'Nigeria'),
(19, 'Panama'),
(20, 'Peru'),
(21, 'Poland'),
(22, 'Portugal'),
(23, 'Russia'),
(24, 'Saudi Arabia'),
(25, 'Senegal'),
(26, 'Serbia'),
(28, 'Spain'),
(29, 'Sweden'),
(30, 'Switzerland'),
(31, 'Tunisia'),
(32, 'Uruguay');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_match`
--

DROP TABLE IF EXISTS `tbl_match`;
CREATE TABLE IF NOT EXISTS `tbl_match` (
  `id` int(11) NOT NULL,
  `match_date` datetime NOT NULL,
  `team_1` int(11) NOT NULL,
  `team_1_goal` int(11) NOT NULL,
  `team_2` int(11) NOT NULL,
  `team_2_goal` int(11) NOT NULL,
  `winner` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=65 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_match`
--

INSERT INTO `tbl_match` (`id`, `match_date`, `team_1`, `team_1_goal`, `team_2`, `team_2_goal`, `winner`) VALUES
(1, '2018-06-14 20:45:00', 23, 0, 24, 0, 0),
(2, '2018-06-15 17:45:00', 9, 0, 32, 0, 0),
(3, '2018-06-15 20:45:00', 17, 0, 14, 0, 0),
(4, '2018-06-15 23:45:00', 22, 0, 28, 0, 0),
(5, '2018-06-16 15:45:00', 11, 0, 2, 0, 0),
(6, '2018-06-16 18:45:00', 1, 0, 13, 0, 0),
(7, '2018-06-16 21:45:00', 20, 0, 8, 0, 0),
(8, '2018-06-17 00:45:00', 7, 0, 18, 0, 0),
(9, '2018-06-17 17:45:00', 6, 0, 26, 0, 0),
(10, '2018-06-17 20:45:00', 12, 0, 16, 0, 0),
(11, '2018-06-17 23:45:00', 4, 0, 30, 0, 0),
(12, '2018-06-18 17:45:00', 29, 0, 27, 0, 0),
(13, '2018-06-18 20:45:00', 3, 0, 19, 0, 0),
(14, '2018-06-18 23:45:00', 31, 0, 10, 0, 0),
(15, '2018-06-19 17:45:00', 5, 0, 15, 0, 0),
(16, '2018-06-19 20:45:00', 21, 0, 25, 0, 0),
(17, '2018-06-19 23:45:00', 23, 0, 9, 0, 0),
(18, '2018-06-20 17:45:00', 22, 0, 17, 0, 0),
(19, '2018-06-20 20:45:00', 32, 0, 24, 0, 0),
(20, '2018-06-20 23:45:00', 14, 0, 28, 0, 0),
(21, '2018-06-21 17:45:00', 8, 0, 2, 0, 0),
(22, '2018-06-21 20:45:00', 11, 0, 20, 0, 0),
(23, '2018-06-21 23:45:00', 1, 0, 7, 0, 0),
(24, '2018-06-22 17:45:00', 4, 0, 6, 0, 0),
(25, '2018-06-22 20:45:00', 18, 0, 13, 0, 0),
(26, '2018-06-22 23:45:00', 26, 0, 30, 0, 0),
(27, '2018-06-23 17:45:00', 3, 0, 31, 0, 0),
(28, '2018-06-23 20:45:00', 27, 0, 16, 0, 0),
(29, '2018-06-23 23:45:00', 12, 0, 29, 0, 0),
(30, '2018-06-24 17:45:00', 10, 0, 19, 0, 0),
(31, '2018-06-24 20:45:00', 15, 0, 25, 0, 0),
(32, '2018-06-24 23:45:00', 21, 0, 5, 0, 0),
(33, '2018-06-25 19:45:00', 32, 0, 23, 0, 0),
(34, '2018-06-25 19:45:00', 24, 0, 9, 0, 0),
(35, '2018-06-25 23:45:00', 28, 0, 17, 0, 0),
(36, '2018-06-25 23:45:00', 14, 0, 22, 0, 0),
(37, '2018-06-26 19:45:00', 2, 0, 20, 0, 0),
(38, '2018-06-26 19:45:00', 8, 0, 11, 0, 0),
(39, '2018-06-26 23:45:00', 18, 0, 1, 0, 0),
(40, '2018-06-26 23:45:00', 13, 0, 7, 0, 0),
(41, '2018-06-27 19:45:00', 27, 0, 12, 0, 0),
(42, '2018-06-27 19:45:00', 16, 0, 29, 0, 0),
(43, '2018-06-27 23:45:00', 26, 0, 4, 0, 0),
(44, '2018-06-27 23:45:00', 30, 0, 6, 0, 0),
(45, '2018-06-28 19:45:00', 15, 0, 21, 0, 0),
(46, '2018-06-28 19:45:00', 25, 0, 5, 0, 0),
(47, '2018-06-28 23:45:00', 19, 0, 31, 0, 0),
(48, '2018-06-28 23:45:00', 10, 0, 3, 0, 0),
(49, '0000-00-00 00:00:00', 0, 0, 0, 0, 0),
(50, '0000-00-00 00:00:00', 0, 0, 0, 0, 0),
(51, '0000-00-00 00:00:00', 0, 0, 0, 0, 0),
(52, '0000-00-00 00:00:00', 0, 0, 0, 0, 0),
(53, '0000-00-00 00:00:00', 0, 0, 0, 0, 0),
(54, '0000-00-00 00:00:00', 0, 0, 0, 0, 0),
(55, '0000-00-00 00:00:00', 0, 0, 0, 0, 0),
(56, '0000-00-00 00:00:00', 0, 0, 0, 0, 0),
(57, '0000-00-00 00:00:00', 0, 0, 0, 0, 0),
(58, '0000-00-00 00:00:00', 0, 0, 0, 0, 0),
(59, '0000-00-00 00:00:00', 0, 0, 0, 0, 0),
(60, '0000-00-00 00:00:00', 0, 0, 0, 0, 0),
(61, '0000-00-00 00:00:00', 0, 0, 0, 0, 0),
(62, '0000-00-00 00:00:00', 0, 0, 0, 0, 0),
(63, '0000-00-00 00:00:00', 0, 0, 0, 0, 0),
(64, '0000-00-00 00:00:00', 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_players`
--

DROP TABLE IF EXISTS `tbl_players`;
CREATE TABLE IF NOT EXISTS `tbl_players` (
  `id` int(11) NOT NULL,
  `country_id` int(11) NOT NULL,
  `player_name` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=638 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_players`
--

INSERT INTO `tbl_players` (`id`, `country_id`, `player_name`) VALUES
(12, 1, 'Angel Di Maria'),
(13, 1, 'Cristian Ansaldi'),
(14, 1, 'Cristian Pavon'),
(15, 1, 'Eduardo Salvio'),
(16, 1, 'Ever Banega'),
(17, 1, 'Federico Fazio'),
(18, 1, 'Franco Armani'),
(19, 1, 'Gabriel Mercado'),
(20, 1, 'Gio Lo Celso'),
(21, 1, 'Gonzalo Higuain'),
(22, 1, 'Javier Mascherano'),
(23, 1, 'Lionel Messi'),
(24, 1, 'Lucas Biglia'),
(25, 1, 'Manuel Lanzini'),
(26, 1, 'Marcos Acuna'),
(27, 1, 'Marcos Rojo'),
(28, 1, 'Maximiliano Meza'),
(29, 1, 'Nahuel Guzmán'),
(30, 1, 'Nicolas Otamendi'),
(31, 1, 'Nicolas Tagliafico'),
(32, 1, 'Paulo Dybala '),
(33, 1, 'Sergio Aguero'),
(34, 1, 'Willy Caballero'),
(35, 2, 'Aaron Mooy'),
(36, 2, 'Andrew Nabbout'),
(37, 2, 'Aziz Behich'),
(38, 2, 'Brad Jones'),
(39, 2, 'Daniel Arzani'),
(40, 2, 'Danny Vukovic'),
(41, 2, 'Dimitri Petratos'),
(42, 2, 'Jackson Irvine'),
(43, 2, 'James Meredith'),
(44, 2, 'Jamie Maclaren'),
(45, 2, 'Josh Risdon'),
(46, 2, 'Mark Milligan'),
(47, 2, 'Massimo Luongo'),
(48, 2, 'Mat Ryan'),
(49, 2, 'Mathew Leckie'),
(50, 2, 'Matthew Jurman'),
(51, 2, 'Mile Jedinak'),
(52, 2, 'Milos Degenek'),
(53, 2, 'Robbie Kruse'),
(54, 2, 'Tim Cahill'),
(55, 2, 'Tom Rogic'),
(56, 2, 'Tomi Juric'),
(57, 2, 'Trent Sainsbury'),
(59, 4, 'Alisson'),
(60, 4, 'Casemiro'),
(61, 4, 'Cassio'),
(62, 4, 'Danilo'),
(63, 4, 'Douglas Costa'),
(64, 4, 'Ederson'),
(65, 4, 'Fagner'),
(66, 4, 'Fernandinho'),
(67, 4, 'Filipe Luis'),
(68, 4, 'Fred'),
(69, 4, 'Gabriel Jesus'),
(70, 4, 'Marcelo'),
(71, 4, 'Marquinhos'),
(72, 4, 'Miranda'),
(73, 4, 'Neymar'),
(74, 4, 'Paulinho'),
(75, 4, 'Pedro Geromel'),
(76, 4, 'Philippe Coutinho'),
(77, 4, 'Renato Augusto'),
(78, 4, 'Roberto Firmino'),
(79, 4, 'Taison'),
(80, 4, 'Thiago Silva'),
(81, 4, 'Willian'),
(82, 7, 'Andrej Kramaric'),
(83, 7, 'Ante Rebic'),
(84, 7, 'Danijel Subasic'),
(85, 7, 'Dejan Lovren'),
(86, 7, 'Domagoj Vida'),
(87, 7, 'Dominik Livakovic'),
(88, 7, 'Duje Caleta-Car'),
(89, 7, 'Filip Bradaric'),
(90, 7, 'Ivan Perisic'),
(91, 7, 'Ivan Rakitic'),
(92, 7, 'Ivan Strinic'),
(93, 7, 'Josip Pivaric'),
(94, 7, 'Lovre Kalinic'),
(95, 7, 'Luka Modric'),
(96, 7, 'Marcelo Brozovic'),
(97, 7, 'Mario Mandzukic'),
(98, 7, 'Marko Pjaca'),
(99, 7, 'Mateo Kovacic'),
(100, 7, 'Milan Badelj'),
(101, 7, 'Nikola Kalinic'),
(102, 7, 'Sime Vrsaljko'),
(103, 7, 'Tin Jedvaj'),
(104, 7, 'Vedran Corluka'),
(105, 9, 'Abdallah Said'),
(106, 9, 'Ahmed Elmohamady'),
(107, 9, 'Ahmed Fathi'),
(108, 9, 'Ahmed Hegazi'),
(109, 9, 'Ali Gabr'),
(110, 9, 'Amr Warda'),
(111, 9, 'Ayman Ashraf'),
(112, 9, 'Essam El Hadary'),
(113, 9, 'Mahmoud Elwensh'),
(114, 9, 'Mahmoud Kahraba'),
(115, 9, 'Mahmoud Shikabala'),
(116, 9, 'Marwan Mohsen'),
(117, 9, 'Mohamed Abdel-Shafy'),
(118, 9, 'Mohamed El-Shennawy'),
(119, 9, 'Mohamed Elneny'),
(120, 9, 'Mohamed Salah'),
(121, 9, 'Omar Gaber'),
(122, 9, 'Ramadan Sobhi'),
(123, 9, 'Saad Samir'),
(124, 9, 'Sam Morsy'),
(125, 9, 'Sherif Ekramy'),
(126, 9, 'Tarek Hamed'),
(127, 9, 'Trezeguet'),
(128, 11, 'Adil Rami'),
(129, 11, 'Alphonse Areola'),
(130, 11, 'Antoine Griezmann'),
(131, 11, 'Benjamin Mendy'),
(132, 11, 'Benjamin Pavard'),
(133, 11, 'Blaise Matuidi'),
(134, 11, 'Corentin Tolisso'),
(135, 11, 'Djibril Sidibe'),
(136, 11, 'Florian Thauvin'),
(137, 11, 'Hugo Lloris'),
(138, 11, 'Kylian Mbappe '),
(139, 11, 'Lucas Hernandez'),
(140, 11, 'N''Golo Kante'),
(141, 11, 'Nabil Fekir'),
(142, 11, 'Olivier Giroud'),
(143, 11, 'Ousmane Dembele'),
(144, 11, 'Paul Pogba'),
(146, 11, 'Presnel Kimpembe'),
(147, 11, 'Raphael Varane'),
(148, 11, 'Samuel Umtiti'),
(149, 11, 'Steve Mandanda'),
(150, 11, 'Steven N''Zonzi'),
(151, 11, 'Thomas Lemar'),
(152, 13, 'Albert Gudmundsson'),
(153, 13, 'Alfred Finnbogason'),
(154, 13, 'Ari Freyr Skulason'),
(155, 13, 'Arnor Ingvi Traustason'),
(156, 13, 'Aron Gunnarsson'),
(157, 13, 'Birkir Bjarnason'),
(158, 13, 'Birkir Mar Saevarsson'),
(159, 13, 'Bjorn Bergmann Sigurdarson'),
(160, 13, 'Emil Hallfredsson'),
(161, 13, 'Frederik Schram'),
(162, 13, 'Gylfi Sigurdsson'),
(163, 13, 'Hannes Thor Halldorsson'),
(164, 13, 'Holmar Orn Eyjolfsson'),
(165, 13, 'Hordur Magnusson'),
(166, 13, 'Johann Berg Gudmundsson'),
(167, 13, 'Jon Dadi Bodvarsson'),
(168, 13, 'Kari Arnason'),
(169, 13, 'Olafur Ingi Skulason'),
(170, 13, 'Ragnar Sigurdsson'),
(171, 13, 'Runar Alex Runarsson'),
(172, 13, 'Rurik Gislason'),
(173, 13, 'Samuel Fridjonsson'),
(174, 13, 'Sverrir Ingi Ingason'),
(175, 14, 'Alireza Beiranvand'),
(176, 14, 'Alireza Jahanbakhsh'),
(177, 14, 'Amir Abedzadeh'),
(178, 14, 'Ashkan Dejagah'),
(179, 14, 'Ehsan Hajsafi'),
(180, 14, 'Karim Ansarifard'),
(181, 14, 'Mahdi Taremi'),
(182, 14, 'Masoud Shojaei'),
(183, 14, 'Mehdi Torabi'),
(184, 14, 'Milad Mohammadi'),
(185, 14, 'Mohammad Reza Khanzadeh'),
(186, 14, 'Morteza Pouraliganji'),
(187, 14, 'Omid Ebrahimi'),
(188, 14, 'Pejman Montazeri'),
(189, 14, 'Ramin Rezaeian'),
(190, 14, 'Rashid Mazaheri'),
(191, 14, 'Reza Ghoochannejhad'),
(192, 14, 'Roozbeh Cheshmi'),
(193, 14, 'Saeid Ezatolahi'),
(194, 14, 'Saman Ghoddos'),
(195, 14, 'Sardar Azmoun'),
(196, 14, 'Seyed Majid Hosseini'),
(197, 14, 'Vahid Amiri'),
(198, 18, 'Abdullahi Shehu'),
(199, 18, 'Ahmed Musa'),
(200, 18, 'Alex Iwobi'),
(201, 18, 'Bryan Idowu'),
(202, 18, 'Chidozie Awaziem'),
(203, 18, 'Daniel Akpeyi'),
(204, 18, 'Elderson Echiejile'),
(205, 18, 'Francis Uzoho'),
(206, 18, 'Ikechukwu Ezenwa'),
(207, 18, 'Joel Obi'),
(208, 18, 'John Obi Mikel'),
(209, 18, 'John Ogu'),
(210, 18, 'Kelechi Iheanacho'),
(211, 18, 'Kelechi Iheanacho'),
(212, 18, 'Kenneth Omeruo'),
(213, 18, 'Leon Balogun'),
(214, 18, 'Odion Ighalo'),
(215, 18, 'Ogenyi Onazi'),
(216, 18, 'Oghenekaro Etebo'),
(217, 18, 'Simeon Nwankwo'),
(218, 18, 'Tyronne Ebuehi'),
(219, 18, 'Victor Moses'),
(220, 18, 'Wilfred Ndidi'),
(221, 18, 'William Troost-Ekong'),
(222, 20, 'Alberto Rodriguez'),
(223, 20, 'Aldo Corzo'),
(224, 20, 'Anderson Santamaria'),
(225, 20, 'Andre Carrillo'),
(226, 20, 'Andy Polo'),
(227, 20, 'Carlos Caceda'),
(228, 20, 'Christian Cueva'),
(229, 20, 'Christian Ramos'),
(230, 20, 'Edison Flores'),
(231, 20, 'Jefferson Farfan'),
(232, 20, 'Jose Carvallo'),
(233, 20, 'Luis Advincula'),
(234, 20, 'Miguel Araujo'),
(235, 20, 'Miguel Trauco'),
(236, 20, 'Nilson Loyola'),
(237, 20, 'Paolo Guerrero'),
(238, 20, 'Paolo Hurtado'),
(239, 20, 'Pedro Aquino'),
(240, 20, 'Pedro Gallese'),
(241, 20, 'Raul Ruidiaz'),
(242, 20, 'Renato Tapia'),
(243, 20, 'Wilder Cartagena'),
(244, 20, 'Yoshimar Yotun '),
(245, 32, 'Carlos Sanchez'),
(246, 32, 'Cristhian Stuani'),
(247, 32, 'Cristian Rodriguez'),
(248, 32, 'Diego Godin'),
(249, 32, 'Diego Laxalt'),
(250, 32, 'Edinson Cavani'),
(251, 32, 'Fernando Muslera'),
(252, 32, 'Gaston Silva'),
(253, 32, 'Giorgian De Arrascaeta'),
(254, 32, 'Guillermo Varela'),
(255, 32, 'Jonathan Urretaviscaya'),
(256, 32, 'Jose Maria Gimenez'),
(257, 32, 'Lucas Torreira'),
(258, 32, 'Luis Suarez'),
(259, 32, 'Martin Caceres'),
(260, 32, 'Martin Campana'),
(261, 32, 'Martin Silva'),
(262, 32, 'Matias Vecino'),
(263, 32, 'Maximiliano Gomez'),
(264, 32, 'Maximiliano Pereira'),
(265, 32, 'Nahitan Nandez'),
(266, 32, 'Rodrigo Bentancur'),
(267, 32, 'Sebastian Coates'),
(268, 3, 'Adnan Januzaj'),
(269, 3, 'Axel Witsel'),
(270, 3, 'Dedryck Boyata'),
(271, 3, 'Dries Mertens'),
(272, 3, 'Eden Hazard'),
(273, 3, 'Jan Vertonghen'),
(274, 3, 'Kevin De Bruyne'),
(275, 3, 'Koen Casteels'),
(276, 3, 'Leander Dendoncker'),
(277, 3, 'Marouane Fellaini'),
(278, 3, 'Michy Batshuayi'),
(279, 3, 'Mousa Dembele'),
(280, 3, 'Nacer Chadli'),
(281, 3, 'Romelu Lukaku'),
(282, 3, 'Simon Mignolet'),
(283, 3, 'Thibaut Courtois'),
(284, 3, 'Thomas Meunier'),
(285, 3, 'Thomas Vermaelen'),
(286, 3, 'Thorgan Hazard'),
(287, 3, 'Toby Alderweireld'),
(288, 3, 'Vincent Kompany'),
(289, 3, 'Yannick Carrasco'),
(290, 3, 'Youri Tielemans'),
(291, 5, 'Abel Aguilar'),
(292, 5, 'Camilo Vargas'),
(293, 5, 'Carlos Bacca'),
(294, 5, 'Carlos Sanchez'),
(295, 5, 'Cristian Zapata'),
(296, 5, 'David Ospina'),
(297, 5, 'Davinson Sanchez'),
(298, 5, 'Frank Fabra'),
(299, 5, 'James Rodriguez'),
(300, 5, 'Jefferson Lerma'),
(301, 5, 'Johan Mojica'),
(302, 5, 'Jose Fernando Cuadrado'),
(303, 5, 'Jose Izquierdo'),
(304, 5, 'Juan Fernando Quintero'),
(305, 5, 'Juan Guillermo Cuadrado'),
(306, 5, 'Luis Fernando Muriel'),
(307, 5, 'Mateus Uribe'),
(308, 5, 'Miguel Borja'),
(309, 5, 'Oscar Murillo'),
(310, 5, 'Radamel Falcao Garcia'),
(311, 5, 'Santiago Arias'),
(312, 5, 'Wilmar Barrios'),
(313, 5, 'Yerry Mina'),
(314, 6, 'Bryan Oviedo'),
(315, 6, 'Bryan Ruiz'),
(316, 6, 'Celso Borges'),
(317, 6, 'Christian Bolanos'),
(318, 6, 'Cristian Gamboa'),
(319, 6, 'Daniel Colindres'),
(320, 6, 'David Guzman'),
(321, 6, 'Francisco Calvo'),
(322, 6, 'Giancarlo Gonzalez'),
(323, 6, 'Ian Smith'),
(324, 6, 'Joel Campbell'),
(325, 6, 'Johan Venegas'),
(326, 6, 'Johnny Acosta'),
(327, 6, 'Kendall Waston'),
(328, 6, 'Keylor Navas'),
(329, 6, 'Leonel Moreira'),
(330, 6, 'Marco Urena'),
(331, 6, 'Oscar Duarte'),
(332, 6, 'Patrick Pemberton'),
(333, 6, 'Randall Azofeifa'),
(334, 6, 'Rodney Wallace'),
(335, 6, 'Ronald Matarrita'),
(336, 6, 'Yeltsin Tejeda'),
(360, 8, 'Andreas Christensen'),
(361, 8, 'Andreas Cornelius'),
(362, 8, 'Christian Eriksen'),
(363, 8, 'Frederik Ronow'),
(364, 8, 'Henrik Dalsgaard'),
(365, 8, 'Jannik Vestergaard'),
(366, 8, 'Jens Stryger'),
(367, 8, 'Jonas Knudsen'),
(368, 8, 'Jonas Lossl'),
(369, 8, 'Kasper Dolberg'),
(370, 8, 'Kasper Schmeichel'),
(371, 8, 'Lasse Schone'),
(372, 8, 'Lukas Lerager'),
(373, 8, 'Martin Braithwaite'),
(374, 8, 'Mathias Jorgensen'),
(375, 8, 'Michael Krohn-Dehli'),
(376, 8, 'Nicolai Jorgensen '),
(377, 8, 'Pione Sisto'),
(378, 8, 'Simon Kjaer'),
(379, 8, 'Thomas Delaney'),
(380, 8, 'Viktor Fischer'),
(381, 8, 'William Kvist'),
(382, 8, 'Yussuf Poulsen'),
(383, 10, 'Ashley Young'),
(384, 10, 'Danny Rose'),
(385, 10, 'Danny Welbeck'),
(386, 10, 'Dele Alli'),
(387, 10, 'Eric Dier'),
(388, 10, 'Fabian Delph'),
(389, 10, 'Gary Cahill'),
(390, 10, 'Harry Kane'),
(391, 10, 'Harry Maguire'),
(392, 10, 'Jack Butland'),
(393, 10, 'Jamie Vardy'),
(394, 10, 'Jesse Lingard'),
(395, 10, 'John Stones'),
(396, 10, 'Jordan Henderson'),
(397, 10, 'Jordan Pickford'),
(398, 10, 'Kieran Trippier'),
(399, 10, 'Kyle Walker'),
(400, 10, 'Marcus Rashford'),
(401, 10, 'Nick Pope'),
(402, 10, 'Phil Jones'),
(403, 10, 'Raheem Sterling'),
(404, 10, 'Ruben Loftus-Cheek'),
(405, 10, 'Trent Alexander-Arnold'),
(406, 12, 'Antonio Rudiger'),
(407, 12, 'Ilkay Gundogan'),
(408, 12, 'Ilkay Gundogan'),
(409, 12, 'Jerome Boateng'),
(410, 12, 'Jonas Hector'),
(411, 12, 'Joshua Kimmich'),
(412, 12, 'Julian Brandt'),
(413, 12, 'Julian Draxler'),
(414, 12, 'Kevin Trapp'),
(415, 12, 'Leon Goretzka'),
(416, 12, 'Manuel Neuer'),
(417, 12, 'Marc-Andre ter Stegen'),
(418, 12, 'Marco Reus'),
(419, 12, 'Mario Gomez'),
(420, 12, 'Marvin Plattenhardt'),
(421, 12, 'Mats Hummels'),
(422, 12, 'Matthias Ginter'),
(423, 12, 'Mesut Ozil'),
(424, 12, 'Niklas Sule'),
(425, 12, 'Sami Khedira'),
(426, 12, 'Sebastian Rudy'),
(427, 12, 'Thomas Muller'),
(428, 12, 'Timo Werner'),
(429, 12, 'Toni Kroos'),
(430, 15, 'Eiji Kawashima'),
(431, 15, 'Gaku Shibasaki'),
(432, 15, 'Gen Shoji'),
(433, 15, 'Genki Haraguchi'),
(434, 15, 'Gotoku Sakai'),
(435, 15, 'Hiroki Sakai'),
(436, 15, 'Hotaru Yamaguchi'),
(437, 15, 'Keisuke Honda'),
(438, 15, 'Kosuke Nakamura'),
(439, 15, 'Makoto Hasebe'),
(440, 15, 'Masaaki Higashiguchi'),
(441, 15, 'Maya Yoshida'),
(442, 15, 'Naomichi Ueda'),
(443, 15, 'Ryota Oshima'),
(444, 15, 'Shinji Kagawa'),
(445, 15, 'Shinji Okazaki'),
(446, 15, 'Takashi Inui'),
(447, 15, 'Takashi Usami'),
(448, 15, 'Tomoaki Makino'),
(449, 15, 'Wataru Endo'),
(450, 15, 'Yoshinori Muto'),
(451, 15, 'Yuto Nagatomo'),
(452, 15, 'Yuya Osako'),
(453, 16, 'Alfredo Talavera'),
(454, 16, 'Andres Guardado'),
(455, 16, 'Carlos Salcedo'),
(456, 16, 'Carlos Vela'),
(457, 16, 'Diego Reyes'),
(458, 16, 'Edson Alvarez'),
(459, 16, 'Giovani dos Santos'),
(460, 16, 'Guillermo Ochoa'),
(461, 16, 'Hector Herrera'),
(462, 16, 'Hector Moreno'),
(463, 16, 'Hirving Lozano'),
(464, 16, 'Hugo Ayala'),
(465, 16, 'Javier Aquino'),
(466, 16, 'Javier Hernandez'),
(467, 16, 'Jesus Corona'),
(468, 16, 'Jesus Gallardo'),
(469, 16, 'Jonathan dos Santos'),
(470, 16, 'Jose Corona'),
(471, 16, 'Marco Fabian'),
(472, 16, 'Miguel Layun'),
(473, 16, 'Oribe Peralta'),
(474, 16, 'Rafael Marquez'),
(475, 16, 'Raul Jimenez'),
(476, 17, 'Achraf Hakimi'),
(477, 17, 'Ahmad Reda Tagnaouti'),
(478, 17, 'Amine Harit'),
(479, 17, 'Ayoub El Kaabi'),
(480, 17, 'Aziz Bouhaddouz'),
(481, 17, 'Badr Benoun'),
(482, 17, 'Faycal Fajr'),
(483, 17, 'Hakim Ziyech'),
(484, 17, 'Hamza Mendyl'),
(485, 17, 'Karim El Ahmadi'),
(486, 17, 'Khalid Boutaib'),
(487, 17, 'M''bark Boussoufa'),
(488, 17, 'Manuel Da Costa'),
(489, 17, 'Mehdi Benatia'),
(490, 17, 'Mehdi Carcela'),
(491, 17, 'Mounir El Kajoui'),
(492, 17, 'Nabil Dirar'),
(493, 17, 'Nordin Amrabat'),
(494, 17, 'Romain Saiss'),
(495, 17, 'Sofyan Amrabat'),
(496, 17, 'Yassine Bounou'),
(497, 17, 'Younes Belhanda'),
(498, 17, 'Youssef Ait Bennasser'),
(499, 19, 'Abdiel Arroyo'),
(500, 19, 'Adolfo Machado'),
(501, 19, 'Alberto Quintero'),
(502, 19, 'Alex Rodríguez'),
(503, 19, 'Anibal Godoy'),
(504, 19, 'Armando Cooper'),
(505, 19, 'Blas Perez'),
(506, 19, 'Edgar Barcenas'),
(507, 19, 'Eric Davis'),
(508, 19, 'Felipe Baloy'),
(509, 19, 'Fidel Escobar'),
(510, 19, 'Gabriel Gomez'),
(511, 19, 'Gabriel Torres'),
(512, 19, 'Harold Cummings'),
(513, 19, 'Ismael Diaz'),
(514, 19, 'Jaime Penedo'),
(515, 19, 'Jose Calderon'),
(516, 19, 'Jose Luis Rodriguez'),
(517, 19, 'Luis Ovalle'),
(518, 19, 'Luis Tejada'),
(519, 19, 'Michael Murillo'),
(520, 19, 'Roman Torres'),
(521, 19, 'Valentin Pimentel'),
(522, 21, 'Arkadiusz Milik'),
(523, 21, 'Artur Jedrzejczyk'),
(524, 21, 'Bartosz Bereszynski'),
(525, 21, 'Bartosz Bialkowski'),
(526, 21, 'Dawid Kownacki'),
(527, 21, 'Grzegorz Krychowiak'),
(528, 21, 'Jacek Goralski'),
(529, 21, 'Jakub Blaszczykowski'),
(530, 21, 'Jan Bednarek'),
(531, 21, 'Kamil Glik'),
(532, 21, 'Kamil Goricki'),
(533, 21, 'Karol Linetty'),
(534, 21, 'Lukasz Fabianski'),
(535, 21, 'Lukasz Piszczek'),
(536, 21, 'Lukasz Teodorczyk'),
(537, 21, 'Maciej Rybus'),
(538, 21, 'Michal Pazdan'),
(539, 21, 'Piotr Zielinski'),
(540, 21, 'Rafal Kurzawa'),
(541, 21, 'Robert Lewandowski'),
(542, 21, 'Slawomir Peszko'),
(543, 21, 'Thiago Cionek'),
(544, 21, 'Wojciech Szczesny'),
(545, 22, 'Adrien Silva'),
(546, 22, 'Andre Silva'),
(547, 22, 'Anthony Lopes'),
(548, 22, 'Bernardo Silva'),
(549, 22, 'Beto'),
(550, 22, 'Bruno Alves'),
(551, 22, 'Bruno Fernandes'),
(552, 22, 'Cedric Soares'),
(553, 22, 'Cristiano Ronaldo'),
(554, 22, 'Gelson Martins'),
(555, 22, 'Goncalo Guedes'),
(556, 22, 'Joao Mario'),
(557, 22, 'Joao Moutinho'),
(558, 22, 'Jose Fonte'),
(559, 22, 'Manuel Fernandes'),
(560, 22, 'Mario Rui'),
(561, 22, 'Pepe'),
(562, 22, 'Raphael Guerreiro'),
(563, 22, 'Ricardo Pereira'),
(564, 22, 'Ricardo Quaresma'),
(565, 22, 'Ruben Dias '),
(566, 22, 'Rui Patricio'),
(567, 22, 'William Carvalho'),
(568, 23, 'Alan Dzagoev'),
(569, 23, 'Aleksandr Golovin'),
(570, 23, 'Aleksandr Samedov'),
(571, 23, 'Aleksandr Yerokhin'),
(572, 23, 'Aleksei Miranchuk'),
(573, 23, 'Andrei Semyonov'),
(574, 23, 'Andrey Lunev'),
(575, 23, 'Anton Miranchuk'),
(576, 23, 'Artyom Dzyuba'),
(577, 23, 'Daler Kuzyaev'),
(578, 23, 'Denis Cheryshev'),
(579, 23, 'Fyodor Kudryashov'),
(580, 23, 'Fyodor Smolov'),
(581, 23, 'Igor Akinfeev'),
(582, 23, 'Igor Smolnikov'),
(583, 23, 'Ilya Kutepov'),
(584, 23, 'Mario Fernandes'),
(585, 23, 'Roman Zobnin'),
(586, 23, 'Sergei Ignashevich'),
(587, 23, 'Vladimir Gabulov'),
(588, 23, 'Vladimir Granat'),
(589, 23, 'Yuri Gazinsky'),
(590, 23, 'Yuri Zhirkov'),
(591, 24, 'Abdullah Al-Mayuf'),
(592, 24, 'Abdullah Alkhaibari'),
(593, 24, 'Abdullah Otayf'),
(594, 24, 'Abdulmalek Alkhaibri'),
(595, 24, 'Ali Al-Bulaihi'),
(596, 24, 'Fahad Al-Muwallad'),
(597, 24, 'Hatan Bahbir'),
(598, 24, 'Hussain Al-Moqahwi'),
(599, 24, 'Mansoor Al-Harbi'),
(600, 24, 'Mohamed Kanno'),
(601, 24, 'Mohammad Al-Sahlawi'),
(602, 24, 'Mohammed Al-Burayk'),
(603, 24, 'Mohammed Al-Owais'),
(604, 24, 'Motaz Hawsawi'),
(605, 24, 'Muhannad Assiri'),
(606, 24, 'Omar Othman'),
(607, 24, 'Osama Hawsawi'),
(608, 24, 'Salem Al-Dawsari'),
(609, 24, 'Salem Al-Dawsari'),
(610, 24, 'Salman Al-Faraj'),
(611, 24, 'Taiseer Al-Jassam'),
(612, 24, 'Yahia Al-Shehri'),
(613, 24, 'Yasser Al-Musailem'),
(614, 24, 'Yasser Al-Shahrani'),
(615, 25, 'Abdoulaye Diallo'),
(616, 25, 'Alfred Gomis'),
(617, 25, 'Alfred Ndiaye'),
(618, 25, 'Cheikh Ndoye'),
(619, 25, 'Cheikhou Kouyate'),
(620, 25, 'Diafra Sakho'),
(621, 25, 'Diao Keita Balde'),
(622, 25, 'Idrisa Gana Gueye '),
(623, 25, 'Ismaila Sarr'),
(624, 25, 'Kalidou Kalidou'),
(625, 25, 'Kara Mbodji'),
(626, 25, 'Khadim Ndiaye'),
(627, 25, 'Lamine Gassama'),
(628, 25, 'Mame Biram Diouf'),
(629, 25, 'Mbaye Niang'),
(630, 25, 'Moussa Konate'),
(631, 25, 'Moussa Sow'),
(632, 25, 'Moussa Wague'),
(633, 25, 'Pape Alioune Ndiaye'),
(634, 25, 'Sadio Mane'),
(635, 25, 'Salif Sane'),
(636, 25, 'Saliou Ciss'),
(637, 25, 'Youssouf Sabaly');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_questions`
--

DROP TABLE IF EXISTS `tbl_questions`;
CREATE TABLE IF NOT EXISTS `tbl_questions` (
  `id` int(11) NOT NULL,
  `contest_type` enum('1','2','3') NOT NULL DEFAULT '3',
  `match_id` int(11) NOT NULL,
  `question_number` int(11) NOT NULL,
  `datetime` datetime NOT NULL,
  `question` varchar(255) NOT NULL,
  `answer` varchar(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=262 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_questions`
--

INSERT INTO `tbl_questions` (`id`, `contest_type`, `match_id`, `question_number`, `datetime`, `question`, `answer`) VALUES
(1, '1', 1, 1, '0000-00-00 00:00:00', 'Which country will win the match ?', ''),
(2, '1', 1, 2, '0000-00-00 00:00:00', 'What will be the final score of the match ?', ''),
(3, '1', 1, 3, '0000-00-00 00:00:00', 'Which team will score the first goal ?', ''),
(4, '1', 1, 4, '0000-00-00 00:00:00', 'Which player will score the first goal ?', ''),
(5, '1', 2, 1, '0000-00-00 00:00:00', 'Which country will win the match ?', ''),
(6, '1', 2, 2, '0000-00-00 00:00:00', 'What will be the final score of the match ?', ''),
(7, '1', 2, 3, '0000-00-00 00:00:00', 'Which team will score the first goal ?', ''),
(8, '1', 2, 4, '0000-00-00 00:00:00', 'Which player will score the first goal ?', ''),
(9, '1', 3, 1, '0000-00-00 00:00:00', 'Which country will win the match ?', ''),
(10, '1', 3, 2, '0000-00-00 00:00:00', 'What will be the final score of the match ?', ''),
(11, '1', 3, 3, '0000-00-00 00:00:00', 'Which team will score the first goal ?', ''),
(12, '1', 3, 4, '0000-00-00 00:00:00', 'Which player will score the first goal ?', ''),
(13, '1', 4, 1, '0000-00-00 00:00:00', 'Which country will win the match ?', ''),
(14, '1', 4, 2, '0000-00-00 00:00:00', 'What will be the final score of the match ?', ''),
(15, '1', 4, 3, '0000-00-00 00:00:00', 'Which team will score the first goal ?', ''),
(16, '1', 4, 4, '0000-00-00 00:00:00', 'Which player will score the first goal ?', ''),
(17, '1', 5, 1, '0000-00-00 00:00:00', 'Which country will win the match ?', ''),
(18, '1', 5, 2, '0000-00-00 00:00:00', 'What will be the final score of the match ?', ''),
(19, '1', 5, 3, '0000-00-00 00:00:00', 'Which team will score the first goal ?', ''),
(20, '1', 5, 4, '0000-00-00 00:00:00', 'Which player will score the first goal ?', ''),
(21, '1', 6, 1, '0000-00-00 00:00:00', 'Which country will win the match ?', ''),
(22, '1', 6, 2, '0000-00-00 00:00:00', 'What will be the final score of the match ?', ''),
(23, '1', 6, 3, '0000-00-00 00:00:00', 'Which team will score the first goal ?', ''),
(24, '1', 6, 4, '0000-00-00 00:00:00', 'Which player will score the first goal ?', ''),
(25, '1', 7, 1, '0000-00-00 00:00:00', 'Which country will win the match ?', ''),
(26, '1', 7, 2, '0000-00-00 00:00:00', 'What will be the final score of the match ?', ''),
(27, '1', 7, 3, '0000-00-00 00:00:00', 'Which team will score the first goal ?', ''),
(28, '1', 7, 4, '0000-00-00 00:00:00', 'Which player will score the first goal ?', ''),
(29, '1', 8, 1, '0000-00-00 00:00:00', 'Which country will win the match ?', ''),
(30, '1', 8, 2, '0000-00-00 00:00:00', 'What will be the final score of the match ?', ''),
(31, '1', 8, 3, '0000-00-00 00:00:00', 'Which team will score the first goal ?', ''),
(32, '1', 8, 4, '0000-00-00 00:00:00', 'Which player will score the first goal ?', ''),
(33, '1', 9, 1, '0000-00-00 00:00:00', 'Which country will win the match ?', ''),
(34, '1', 9, 2, '0000-00-00 00:00:00', 'What will be the final score of the match ?', ''),
(35, '1', 9, 3, '0000-00-00 00:00:00', 'Which team will score the first goal ?', ''),
(36, '1', 9, 4, '0000-00-00 00:00:00', 'Which player will score the first goal ?', ''),
(37, '1', 10, 1, '0000-00-00 00:00:00', 'Which country will win the match ?', ''),
(38, '1', 10, 2, '0000-00-00 00:00:00', 'What will be the final score of the match ?', ''),
(39, '1', 10, 3, '0000-00-00 00:00:00', 'Which team will score the first goal ?', ''),
(40, '1', 10, 4, '0000-00-00 00:00:00', 'Which player will score the first goal ?', ''),
(41, '1', 11, 1, '0000-00-00 00:00:00', 'Which country will win the match ?', ''),
(42, '1', 11, 2, '0000-00-00 00:00:00', 'What will be the final score of the match ?', ''),
(43, '1', 11, 3, '0000-00-00 00:00:00', 'Which team will score the first goal ?', ''),
(44, '1', 11, 4, '0000-00-00 00:00:00', 'Which player will score the first goal ?', ''),
(45, '1', 12, 1, '0000-00-00 00:00:00', 'Which country will win the match ?', ''),
(46, '1', 12, 2, '0000-00-00 00:00:00', 'What will be the final score of the match ?', ''),
(47, '1', 12, 3, '0000-00-00 00:00:00', 'Which team will score the first goal ?', ''),
(48, '1', 12, 4, '0000-00-00 00:00:00', 'Which player will score the first goal ?', ''),
(49, '1', 13, 1, '0000-00-00 00:00:00', 'Which country will win the match ?', ''),
(50, '1', 13, 2, '0000-00-00 00:00:00', 'What will be the final score of the match ?', ''),
(51, '1', 13, 3, '0000-00-00 00:00:00', 'Which team will score the first goal ?', ''),
(52, '1', 13, 4, '0000-00-00 00:00:00', 'Which player will score the first goal ?', ''),
(53, '1', 14, 1, '0000-00-00 00:00:00', 'Which country will win the match ?', ''),
(54, '1', 14, 2, '0000-00-00 00:00:00', 'What will be the final score of the match ?', ''),
(55, '1', 14, 3, '0000-00-00 00:00:00', 'Which team will score the first goal ?', ''),
(56, '1', 14, 4, '0000-00-00 00:00:00', 'Which player will score the first goal ?', ''),
(57, '1', 15, 1, '0000-00-00 00:00:00', 'Which country will win the match ?', ''),
(58, '1', 15, 2, '0000-00-00 00:00:00', 'What will be the final score of the match ?', ''),
(59, '1', 15, 3, '0000-00-00 00:00:00', 'Which team will score the first goal ?', ''),
(60, '1', 15, 4, '0000-00-00 00:00:00', 'Which player will score the first goal ?', ''),
(61, '1', 16, 1, '0000-00-00 00:00:00', 'Which country will win the match ?', ''),
(62, '1', 16, 2, '0000-00-00 00:00:00', 'What will be the final score of the match ?', ''),
(63, '1', 16, 3, '0000-00-00 00:00:00', 'Which team will score the first goal ?', ''),
(64, '1', 16, 4, '0000-00-00 00:00:00', 'Which player will score the first goal ?', ''),
(65, '1', 17, 1, '0000-00-00 00:00:00', 'Which country will win the match ?', ''),
(66, '1', 17, 2, '0000-00-00 00:00:00', 'What will be the final score of the match ?', ''),
(67, '1', 17, 3, '0000-00-00 00:00:00', 'Which team will score the first goal ?', ''),
(68, '1', 17, 4, '0000-00-00 00:00:00', 'Which player will score the first goal ?', ''),
(69, '1', 18, 1, '0000-00-00 00:00:00', 'Which country will win the match ?', ''),
(70, '1', 18, 2, '0000-00-00 00:00:00', 'What will be the final score of the match ?', ''),
(71, '1', 18, 3, '0000-00-00 00:00:00', 'Which team will score the first goal ?', ''),
(72, '1', 18, 4, '0000-00-00 00:00:00', 'Which player will score the first goal ?', ''),
(73, '1', 19, 1, '0000-00-00 00:00:00', 'Which country will win the match ?', ''),
(74, '1', 19, 2, '0000-00-00 00:00:00', 'What will be the final score of the match ?', ''),
(75, '1', 19, 3, '0000-00-00 00:00:00', 'Which team will score the first goal ?', ''),
(76, '1', 19, 4, '0000-00-00 00:00:00', 'Which player will score the first goal ?', ''),
(77, '1', 20, 1, '0000-00-00 00:00:00', 'Which country will win the match ?', ''),
(78, '1', 20, 2, '0000-00-00 00:00:00', 'What will be the final score of the match ?', ''),
(79, '1', 20, 3, '0000-00-00 00:00:00', 'Which team will score the first goal ?', ''),
(80, '1', 20, 4, '0000-00-00 00:00:00', 'Which player will score the first goal ?', ''),
(81, '1', 21, 1, '0000-00-00 00:00:00', 'Which country will win the match ?', ''),
(82, '1', 21, 2, '0000-00-00 00:00:00', 'What will be the final score of the match ?', ''),
(83, '1', 21, 3, '0000-00-00 00:00:00', 'Which team will score the first goal ?', ''),
(84, '1', 21, 4, '0000-00-00 00:00:00', 'Which player will score the first goal ?', ''),
(85, '1', 22, 1, '0000-00-00 00:00:00', 'Which country will win the match ?', ''),
(86, '1', 22, 2, '0000-00-00 00:00:00', 'What will be the final score of the match ?', ''),
(87, '1', 22, 3, '0000-00-00 00:00:00', 'Which team will score the first goal ?', ''),
(88, '1', 22, 4, '0000-00-00 00:00:00', 'Which player will score the first goal ?', ''),
(89, '1', 23, 1, '0000-00-00 00:00:00', 'Which country will win the match ?', ''),
(90, '1', 23, 2, '0000-00-00 00:00:00', 'What will be the final score of the match ?', ''),
(91, '1', 23, 3, '0000-00-00 00:00:00', 'Which team will score the first goal ?', ''),
(92, '1', 23, 4, '0000-00-00 00:00:00', 'Which player will score the first goal ?', ''),
(93, '1', 24, 1, '0000-00-00 00:00:00', 'Which country will win the match ?', ''),
(94, '1', 24, 2, '0000-00-00 00:00:00', 'What will be the final score of the match ?', ''),
(95, '1', 24, 3, '0000-00-00 00:00:00', 'Which team will score the first goal ?', ''),
(96, '1', 24, 4, '0000-00-00 00:00:00', 'Which player will score the first goal ?', ''),
(97, '1', 25, 1, '0000-00-00 00:00:00', 'Which country will win the match ?', ''),
(98, '1', 25, 2, '0000-00-00 00:00:00', 'What will be the final score of the match ?', ''),
(99, '1', 25, 3, '0000-00-00 00:00:00', 'Which team will score the first goal ?', ''),
(100, '1', 25, 4, '0000-00-00 00:00:00', 'Which player will score the first goal ?', ''),
(101, '1', 26, 1, '0000-00-00 00:00:00', 'Which country will win the match ?', ''),
(102, '1', 26, 2, '0000-00-00 00:00:00', 'What will be the final score of the match ?', ''),
(103, '1', 26, 3, '0000-00-00 00:00:00', 'Which team will score the first goal ?', ''),
(104, '1', 26, 4, '0000-00-00 00:00:00', 'Which player will score the first goal ?', ''),
(105, '1', 27, 1, '0000-00-00 00:00:00', 'Which country will win the match ?', ''),
(106, '1', 27, 2, '0000-00-00 00:00:00', 'What will be the final score of the match ?', ''),
(107, '1', 27, 3, '0000-00-00 00:00:00', 'Which team will score the first goal ?', ''),
(108, '1', 27, 4, '0000-00-00 00:00:00', 'Which player will score the first goal ?', ''),
(109, '1', 28, 1, '0000-00-00 00:00:00', 'Which country will win the match ?', ''),
(110, '1', 28, 2, '0000-00-00 00:00:00', 'What will be the final score of the match ?', ''),
(111, '1', 28, 3, '0000-00-00 00:00:00', 'Which team will score the first goal ?', ''),
(112, '1', 28, 4, '0000-00-00 00:00:00', 'Which player will score the first goal ?', ''),
(113, '1', 29, 1, '0000-00-00 00:00:00', 'Which country will win the match ?', ''),
(114, '1', 29, 2, '0000-00-00 00:00:00', 'What will be the final score of the match ?', ''),
(115, '1', 29, 3, '0000-00-00 00:00:00', 'Which team will score the first goal ?', ''),
(116, '1', 29, 4, '0000-00-00 00:00:00', 'Which player will score the first goal ?', ''),
(117, '1', 30, 1, '0000-00-00 00:00:00', 'Which country will win the match ?', ''),
(118, '1', 30, 2, '0000-00-00 00:00:00', 'What will be the final score of the match ?', ''),
(119, '1', 30, 3, '0000-00-00 00:00:00', 'Which team will score the first goal ?', ''),
(120, '1', 30, 4, '0000-00-00 00:00:00', 'Which player will score the first goal ?', ''),
(121, '1', 31, 1, '0000-00-00 00:00:00', 'Which country will win the match ?', ''),
(122, '1', 31, 2, '0000-00-00 00:00:00', 'What will be the final score of the match ?', ''),
(123, '1', 31, 3, '0000-00-00 00:00:00', 'Which team will score the first goal ?', ''),
(124, '1', 31, 4, '0000-00-00 00:00:00', 'Which player will score the first goal ?', ''),
(125, '1', 32, 1, '0000-00-00 00:00:00', 'Which country will win the match ?', ''),
(126, '1', 32, 2, '0000-00-00 00:00:00', 'What will be the final score of the match ?', ''),
(127, '1', 32, 3, '0000-00-00 00:00:00', 'Which team will score the first goal ?', ''),
(128, '1', 32, 4, '0000-00-00 00:00:00', 'Which player will score the first goal ?', ''),
(129, '1', 33, 1, '0000-00-00 00:00:00', 'Which country will win the match ?', ''),
(130, '1', 33, 2, '0000-00-00 00:00:00', 'What will be the final score of the match ?', ''),
(131, '1', 33, 3, '0000-00-00 00:00:00', 'Which team will score the first goal ?', ''),
(132, '1', 33, 4, '0000-00-00 00:00:00', 'Which player will score the first goal ?', ''),
(133, '1', 34, 1, '0000-00-00 00:00:00', 'Which country will win the match ?', ''),
(134, '1', 34, 2, '0000-00-00 00:00:00', 'What will be the final score of the match ?', ''),
(135, '1', 34, 3, '0000-00-00 00:00:00', 'Which team will score the first goal ?', ''),
(136, '1', 34, 4, '0000-00-00 00:00:00', 'Which player will score the first goal ?', ''),
(137, '1', 35, 1, '0000-00-00 00:00:00', 'Which country will win the match ?', ''),
(138, '1', 35, 2, '0000-00-00 00:00:00', 'What will be the final score of the match ?', ''),
(139, '1', 35, 3, '0000-00-00 00:00:00', 'Which team will score the first goal ?', ''),
(140, '1', 35, 4, '0000-00-00 00:00:00', 'Which player will score the first goal ?', ''),
(141, '1', 36, 1, '0000-00-00 00:00:00', 'Which country will win the match ?', ''),
(142, '1', 36, 2, '0000-00-00 00:00:00', 'What will be the final score of the match ?', ''),
(143, '1', 36, 3, '0000-00-00 00:00:00', 'Which team will score the first goal ?', ''),
(144, '1', 36, 4, '0000-00-00 00:00:00', 'Which player will score the first goal ?', ''),
(145, '1', 37, 1, '0000-00-00 00:00:00', 'Which country will win the match ?', ''),
(146, '1', 37, 2, '0000-00-00 00:00:00', 'What will be the final score of the match ?', ''),
(147, '1', 37, 3, '0000-00-00 00:00:00', 'Which team will score the first goal ?', ''),
(148, '1', 37, 4, '0000-00-00 00:00:00', 'Which player will score the first goal ?', ''),
(149, '1', 38, 1, '0000-00-00 00:00:00', 'Which country will win the match ?', ''),
(150, '1', 38, 2, '0000-00-00 00:00:00', 'What will be the final score of the match ?', ''),
(151, '1', 38, 3, '0000-00-00 00:00:00', 'Which team will score the first goal ?', ''),
(152, '1', 38, 4, '0000-00-00 00:00:00', 'Which player will score the first goal ?', ''),
(153, '1', 39, 1, '0000-00-00 00:00:00', 'Which country will win the match ?', ''),
(154, '1', 39, 2, '0000-00-00 00:00:00', 'What will be the final score of the match ?', ''),
(155, '1', 39, 3, '0000-00-00 00:00:00', 'Which team will score the first goal ?', ''),
(156, '1', 39, 4, '0000-00-00 00:00:00', 'Which player will score the first goal ?', ''),
(157, '1', 40, 1, '0000-00-00 00:00:00', 'Which country will win the match ?', ''),
(158, '1', 40, 2, '0000-00-00 00:00:00', 'What will be the final score of the match ?', ''),
(159, '1', 40, 3, '0000-00-00 00:00:00', 'Which team will score the first goal ?', ''),
(160, '1', 40, 4, '0000-00-00 00:00:00', 'Which player will score the first goal ?', ''),
(161, '1', 41, 1, '0000-00-00 00:00:00', 'Which country will win the match ?', ''),
(162, '1', 41, 2, '0000-00-00 00:00:00', 'What will be the final score of the match ?', ''),
(163, '1', 41, 3, '0000-00-00 00:00:00', 'Which team will score the first goal ?', ''),
(164, '1', 41, 4, '0000-00-00 00:00:00', 'Which player will score the first goal ?', ''),
(165, '1', 42, 1, '0000-00-00 00:00:00', 'Which country will win the match ?', ''),
(166, '1', 42, 2, '0000-00-00 00:00:00', 'What will be the final score of the match ?', ''),
(167, '1', 42, 3, '0000-00-00 00:00:00', 'Which team will score the first goal ?', ''),
(168, '1', 42, 4, '0000-00-00 00:00:00', 'Which player will score the first goal ?', ''),
(169, '1', 43, 1, '0000-00-00 00:00:00', 'Which country will win the match ?', ''),
(170, '1', 43, 2, '0000-00-00 00:00:00', 'What will be the final score of the match ?', ''),
(171, '1', 43, 3, '0000-00-00 00:00:00', 'Which team will score the first goal ?', ''),
(172, '1', 43, 4, '0000-00-00 00:00:00', 'Which player will score the first goal ?', ''),
(173, '1', 44, 1, '0000-00-00 00:00:00', 'Which country will win the match ?', ''),
(174, '1', 44, 2, '0000-00-00 00:00:00', 'What will be the final score of the match ?', ''),
(175, '1', 44, 3, '0000-00-00 00:00:00', 'Which team will score the first goal ?', ''),
(176, '1', 44, 4, '0000-00-00 00:00:00', 'Which player will score the first goal ?', ''),
(177, '1', 45, 1, '0000-00-00 00:00:00', 'Which country will win the match ?', ''),
(178, '1', 45, 2, '0000-00-00 00:00:00', 'What will be the final score of the match ?', ''),
(179, '1', 45, 3, '0000-00-00 00:00:00', 'Which team will score the first goal ?', ''),
(180, '1', 45, 4, '0000-00-00 00:00:00', 'Which player will score the first goal ?', ''),
(181, '1', 46, 1, '0000-00-00 00:00:00', 'Which country will win the match ?', ''),
(182, '1', 46, 2, '0000-00-00 00:00:00', 'What will be the final score of the match ?', ''),
(183, '1', 46, 3, '0000-00-00 00:00:00', 'Which team will score the first goal ?', ''),
(184, '1', 46, 4, '0000-00-00 00:00:00', 'Which player will score the first goal ?', ''),
(185, '1', 47, 1, '0000-00-00 00:00:00', 'Which country will win the match ?', ''),
(186, '1', 47, 2, '0000-00-00 00:00:00', 'What will be the final score of the match ?', ''),
(187, '1', 47, 3, '0000-00-00 00:00:00', 'Which team will score the first goal ?', ''),
(188, '1', 47, 4, '0000-00-00 00:00:00', 'Which player will score the first goal ?', ''),
(189, '1', 48, 1, '0000-00-00 00:00:00', 'Which country will win the match ?', ''),
(190, '1', 48, 2, '0000-00-00 00:00:00', 'What will be the final score of the match ?', ''),
(191, '1', 48, 3, '0000-00-00 00:00:00', 'Which team will score the first goal ?', ''),
(192, '1', 48, 4, '0000-00-00 00:00:00', 'Which player will score the first goal ?', ''),
(193, '1', 49, 1, '0000-00-00 00:00:00', 'Which country will win the match ?', ''),
(194, '1', 49, 2, '0000-00-00 00:00:00', 'What will be the final score of the match ?', ''),
(195, '1', 49, 3, '0000-00-00 00:00:00', 'Which team will score the first goal ?', ''),
(196, '1', 49, 4, '0000-00-00 00:00:00', 'Which player will score the first goal ?', ''),
(197, '1', 50, 1, '0000-00-00 00:00:00', 'Which country will win the match ?', ''),
(198, '1', 50, 2, '0000-00-00 00:00:00', 'What will be the final score of the match ?', ''),
(199, '1', 50, 3, '0000-00-00 00:00:00', 'Which team will score the first goal ?', ''),
(200, '1', 50, 4, '0000-00-00 00:00:00', 'Which player will score the first goal ?', ''),
(201, '1', 51, 1, '0000-00-00 00:00:00', 'Which country will win the match ?', ''),
(202, '1', 51, 2, '0000-00-00 00:00:00', 'What will be the final score of the match ?', ''),
(203, '1', 51, 3, '0000-00-00 00:00:00', 'Which team will score the first goal ?', ''),
(204, '1', 51, 4, '0000-00-00 00:00:00', 'Which player will score the first goal ?', ''),
(205, '1', 52, 1, '0000-00-00 00:00:00', 'Which country will win the match ?', ''),
(206, '1', 52, 2, '0000-00-00 00:00:00', 'What will be the final score of the match ?', ''),
(207, '1', 52, 3, '0000-00-00 00:00:00', 'Which team will score the first goal ?', ''),
(208, '1', 52, 4, '0000-00-00 00:00:00', 'Which player will score the first goal ?', ''),
(209, '1', 53, 1, '0000-00-00 00:00:00', 'Which country will win the match ?', ''),
(210, '1', 53, 2, '0000-00-00 00:00:00', 'What will be the final score of the match ?', ''),
(211, '1', 53, 3, '0000-00-00 00:00:00', 'Which team will score the first goal ?', ''),
(212, '1', 53, 4, '0000-00-00 00:00:00', 'Which player will score the first goal ?', ''),
(213, '1', 54, 1, '0000-00-00 00:00:00', 'Which country will win the match ?', ''),
(214, '1', 54, 2, '0000-00-00 00:00:00', 'What will be the final score of the match ?', ''),
(215, '1', 54, 3, '0000-00-00 00:00:00', 'Which team will score the first goal ?', ''),
(216, '1', 54, 4, '0000-00-00 00:00:00', 'Which player will score the first goal ?', ''),
(217, '1', 55, 1, '0000-00-00 00:00:00', 'Which country will win the match ?', ''),
(218, '1', 55, 2, '0000-00-00 00:00:00', 'What will be the final score of the match ?', ''),
(219, '1', 55, 3, '0000-00-00 00:00:00', 'Which team will score the first goal ?', ''),
(220, '1', 55, 4, '0000-00-00 00:00:00', 'Which player will score the first goal ?', ''),
(221, '1', 56, 1, '0000-00-00 00:00:00', 'Which country will win the match ?', ''),
(222, '1', 56, 2, '0000-00-00 00:00:00', 'What will be the final score of the match ?', ''),
(223, '1', 56, 3, '0000-00-00 00:00:00', 'Which team will score the first goal ?', ''),
(224, '1', 56, 4, '0000-00-00 00:00:00', 'Which player will score the first goal ?', ''),
(225, '1', 57, 1, '0000-00-00 00:00:00', 'Which country will win the match ?', ''),
(226, '1', 57, 2, '0000-00-00 00:00:00', 'What will be the final score of the match ?', ''),
(227, '1', 57, 3, '0000-00-00 00:00:00', 'Which team will score the first goal ?', ''),
(228, '1', 57, 4, '0000-00-00 00:00:00', 'Which player will score the first goal ?', ''),
(229, '1', 58, 1, '0000-00-00 00:00:00', 'Which country will win the match ?', ''),
(230, '1', 58, 2, '0000-00-00 00:00:00', 'What will be the final score of the match ?', ''),
(231, '1', 58, 3, '0000-00-00 00:00:00', 'Which team will score the first goal ?', ''),
(232, '1', 58, 4, '0000-00-00 00:00:00', 'Which player will score the first goal ?', ''),
(233, '1', 59, 1, '0000-00-00 00:00:00', 'Which country will win the match ?', ''),
(234, '1', 59, 2, '0000-00-00 00:00:00', 'What will be the final score of the match ?', ''),
(235, '1', 59, 3, '0000-00-00 00:00:00', 'Which team will score the first goal ?', ''),
(236, '1', 59, 4, '0000-00-00 00:00:00', 'Which player will score the first goal ?', ''),
(237, '1', 60, 1, '0000-00-00 00:00:00', 'Which country will win the match ?', ''),
(238, '1', 60, 2, '0000-00-00 00:00:00', 'What will be the final score of the match ?', ''),
(239, '1', 60, 3, '0000-00-00 00:00:00', 'Which team will score the first goal ?', ''),
(240, '1', 60, 4, '0000-00-00 00:00:00', 'Which player will score the first goal ?', ''),
(241, '1', 61, 1, '0000-00-00 00:00:00', 'Which country will win the match ?', ''),
(242, '1', 61, 2, '0000-00-00 00:00:00', 'What will be the final score of the match ?', ''),
(243, '1', 61, 3, '0000-00-00 00:00:00', 'Which team will score the first goal ?', ''),
(244, '1', 61, 4, '0000-00-00 00:00:00', 'Which player will score the first goal ?', ''),
(245, '1', 62, 1, '0000-00-00 00:00:00', 'Which country will win the match ?', ''),
(246, '1', 62, 2, '0000-00-00 00:00:00', 'What will be the final score of the match ?', ''),
(247, '1', 62, 3, '0000-00-00 00:00:00', 'Which team will score the first goal ?', ''),
(248, '1', 62, 4, '0000-00-00 00:00:00', 'Which player will score the first goal ?', ''),
(249, '1', 63, 1, '0000-00-00 00:00:00', 'Which country will win the match ?', ''),
(250, '1', 63, 2, '0000-00-00 00:00:00', 'What will be the final score of the match ?', ''),
(251, '1', 63, 3, '0000-00-00 00:00:00', 'Which team will score the first goal ?', ''),
(252, '1', 63, 4, '0000-00-00 00:00:00', 'Which player will score the first goal ?', ''),
(253, '1', 64, 1, '0000-00-00 00:00:00', 'Which country will win the match ?', ''),
(254, '1', 64, 2, '0000-00-00 00:00:00', 'What will be the final score of the match ?', ''),
(255, '1', 64, 3, '0000-00-00 00:00:00', 'Which team will score the first goal ?', ''),
(256, '1', 64, 4, '0000-00-00 00:00:00', 'Which player will score the first goal ?', ''),
(257, '2', 0, 0, '0000-00-00 00:00:00', 'Which country will win the World Cup 2018 ?', ''),
(258, '2', 0, 0, '0000-00-00 00:00:00', 'Which two team will reach the World Cup 2018 final ?', ''),
(259, '2', 0, 0, '0000-00-00 00:00:00', 'What will be the final scorer of World Cup 2018 final ?', ''),
(260, '2', 0, 0, '0000-00-00 00:00:00', 'Who will be the best player of the tournament ?', ''),
(261, '2', 0, 0, '0000-00-00 00:00:00', 'Who will be the highest scorer of the tournament ?', '');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_tiesheet`
--

DROP TABLE IF EXISTS `tbl_tiesheet`;
CREATE TABLE IF NOT EXISTS `tbl_tiesheet` (
  `id` int(11) NOT NULL,
  `datetime` datetime NOT NULL,
  `team_1` varchar(255) NOT NULL,
  `goal_from_team_1` int(11) NOT NULL,
  `team_2` varchar(255) NOT NULL,
  `goal_from_team_2` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) unsigned NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `username` varchar(100) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `salt` varchar(255) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `activation_code` varchar(40) DEFAULT NULL,
  `forgotten_password_code` varchar(40) DEFAULT NULL,
  `forgotten_password_time` int(11) unsigned DEFAULT NULL,
  `remember_code` varchar(40) DEFAULT NULL,
  `created_on` int(11) unsigned NOT NULL,
  `last_login` int(11) unsigned DEFAULT NULL,
  `active` tinyint(1) unsigned DEFAULT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `company` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `modules` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `ip_address`, `username`, `password`, `salt`, `email`, `activation_code`, `forgotten_password_code`, `forgotten_password_time`, `remember_code`, `created_on`, `last_login`, `active`, `first_name`, `last_name`, `company`, `phone`, `modules`) VALUES
(1, '127.0.0.1', 'administrator', '$2y$08$9FQL5kCp3cdZEV1yrJHq9O91a/GKNZDBJJ7UyJY1XjCYSm3Jf90IS', '', 'admin@asianpaintsnepal.com', NULL, NULL, NULL, 'uKP1We7wLf61ZnSL.55Nzu', 1268889823, 1528374734, 1, 'Asian Paints', 'Nepal', 'Asian Paints Nepal', '9851237969', '');

-- --------------------------------------------------------

--
-- Table structure for table `users_groups`
--

DROP TABLE IF EXISTS `users_groups`;
CREATE TABLE IF NOT EXISTS `users_groups` (
  `id` int(11) unsigned NOT NULL,
  `user_id` int(11) unsigned NOT NULL,
  `group_id` mediumint(8) unsigned NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users_groups`
--

INSERT INTO `users_groups` (`id`, `user_id`, `group_id`) VALUES
(92, 1, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_contestants`
--
ALTER TABLE `tbl_contestants`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_country`
--
ALTER TABLE `tbl_country`
  ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `country_name` (`country_name`);

--
-- Indexes for table `tbl_match`
--
ALTER TABLE `tbl_match`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_players`
--
ALTER TABLE `tbl_players`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_questions`
--
ALTER TABLE `tbl_questions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_tiesheet`
--
ALTER TABLE `tbl_tiesheet`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `tbl_contestants`
--
ALTER TABLE `tbl_contestants`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tbl_country`
--
ALTER TABLE `tbl_country`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=33;
--
-- AUTO_INCREMENT for table `tbl_match`
--
ALTER TABLE `tbl_match`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=65;
--
-- AUTO_INCREMENT for table `tbl_players`
--
ALTER TABLE `tbl_players`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=638;
--
-- AUTO_INCREMENT for table `tbl_questions`
--
ALTER TABLE `tbl_questions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=262;
--
-- AUTO_INCREMENT for table `tbl_tiesheet`
--
ALTER TABLE `tbl_tiesheet`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
